package com.example.test700;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText amountEditText;
    TextView resultTextView;
    Spinner currencySpinner;

    private double euroRate = 0.091;
    private double usdRate = 0.097;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        amountEditText = findViewById(R.id.editTextNumber2);
        resultTextView = findViewById(R.id.eurview);
        currencySpinner = findViewById(R.id.spinner2);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinnerItems, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        currencySpinner.setAdapter(adapter);

        Button calculateButton = findViewById(R.id.CNV);
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currency = currencySpinner.getSelectedItem().toString();
                calculateResult(currency);
            }
        });
    }

    private void calculateResult(String currency) {
        double amount = Double.parseDouble(amountEditText.getText().toString());
        double result = 0;
        String currencySymbol = "";

        switch (currency) {
            case "EUR":
                result = amount * euroRate;
                currencySymbol = "EURO";
                break;
            case "USD":
                result = amount * usdRate;
                currencySymbol = "USD";
                break;
        }

        String resultText = String.format("%.2f %s", result, currencySymbol);
        resultTextView.setText(resultText);
    }

}